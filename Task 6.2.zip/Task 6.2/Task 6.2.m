fs = 100;  % Sampling frequency (Hz)
fc = 1;    % Cutoff frequency (Hz)
order = 4; % Filter order

% Calculate the filter coefficients
[b, a] = butter(order, fc/(fs/2), 'low');

% Initialize variables
prevTime = 0;
currentTime = 0;
prevPulseCount = 0;
currentPulseCount = 0;
filteredPulseCount = 0;

while true
    % Read encoder pulse count
    currentPulseCount = get Pulsecount();
    
    % Calculate time difference
    currentTime = clock;
    deltaTime = etime(currentTime, prevTime);
    
    % Apply LPF
    filteredPulseCount = filter(b, a, currentPulseCount);
    
    % Calculate velocity based on filtered pulse count and time difference
    velocity = (filteredPulseCount - prevPulseCount) / deltaTime;
    
    % Update previous values for the next iteration
    prevTime = currentTime;
    prevPulseCount = filteredPulseCount;
    
    % Perform other tasks or calculations using the filtered velocity value
    
    pause(0.1);  % Adjust the pause duration as necessary to control the loop rate
end

function pulseCount = getPulseCount()
    % Read the encoder pulse count using appropriate MATLAB functions
    % Return the pulse count value
end