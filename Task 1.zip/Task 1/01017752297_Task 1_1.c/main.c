#include <stdio.h>
#include <stdlib.h>


int main()
{
  char string[] = "GRU";

  printf("%s\n", string);

  return 0;
}
